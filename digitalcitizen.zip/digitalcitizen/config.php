<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "test_project";
$api_key = "tcOYV4ZgFACAwE6muMBXDyYFXMjb920e";

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Errore connessione database: " . $conn->connect_error);
}
?>
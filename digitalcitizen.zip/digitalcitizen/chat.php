<?php
require_once "config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $question = trim($_POST["question"]);

    if (empty($question)) {
        die("Domanda non valida.");
    }

    function callMistralAPI($data, $api_key) {
        $url = "https://api.mistral.ai/v1/chat/completions";
        $ch = curl_init($url);
		

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Content-Type: application/json",
            "Authorization: Bearer " . $api_key
        ]);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

        $response = curl_exec($ch);

        if ($response === false) {
            $error = curl_error($ch);
            curl_close($ch);
            return ["error" => $error];
        }

        curl_close($ch);
        return json_decode($response, true);
    }

    // VALIDAZIONE TEMA
    $validation_prompt = "Controlla se questa domanda riguarda la cittadinanza digitale.
    Se sì rispondi SOLO con VALID.
    Se no rispondi SOLO con INVALID.
    Non essere troppo restrittivo.
    Domanda: " . $question;

    $validation_data = [
        "model" => "mistral-small-latest",
        "messages" => [
            ["role" => "user", "content" => $validation_prompt]
        ],
        "max_tokens" => 5
    ];

    $validation_result = callMistralAPI($validation_data, $api_key);

    $validation_answer = trim(
        $validation_result["choices"][0]["message"]["content"] ?? ""
    );

    if ($validation_answer !== "VALID") {

        $error_message = "La domanda non rientra nella tematica 'cittadinanza digitale'.";

    } else {

        // RISPOSTA AI
        $data = [
            "model" => "mistral-small-latest",
            "messages" => [
                [
                    "role" => "system",
                    "content" => "Rispondi in modo chiaro e didattico a domande sulla cittadinanza digitale. In ciascuna risposta non usare più di 300 token"
                ],
                [
                    "role" => "user",
                    "content" => $question
                ]
            ],
            "max_tokens" => 500
        ];

        $response = callMistralAPI($data, $api_key);

        $answer_original = $response["choices"][0]["message"]["content"] ?? "";


        // PUNTEGGIO DOMANDA
        $score_prompt = "Valuta da 1 a 5 quanto questa domanda dimostra consapevolezza di cittadinanza digitale.
        Rispondi SOLO con un numero da 1 a 5. Nella valutazione devi considerare fattori come la riflessione dello studente sui rischi, citazione di comportamenti responsabili,
		la considerazione di privacy, etica e sicurezza, ed infine il fatto che lo studente faccia domande ragionate e non solo definizioni.
        Domanda: " . $question;

        $score_data = [
            "model" => "mistral-small-latest",
            "messages" => [
                ["role" => "user", "content" => $score_prompt]
            ],
            "max_tokens" => 5
        ];

        $score_response = callMistralAPI($score_data, $api_key);

        $score_raw = trim($score_response["choices"][0]["message"]["content"] ?? "0");

        $score = intval(preg_replace('/[^0-5]/', '', $score_raw));

        if ($score < 1) $score = 1;
        if ($score > 5) $score = 5;


        if (empty($answer_original)) {

            $error_message = "Errore nella risposta AI.";

        } else {

            $question_sql = $conn->real_escape_string($question);
            $answer_sql   = $conn->real_escape_string($answer_original);
            $score_sql    = intval($score);

            $sql = "INSERT INTO test (question, answer, score, created_at)
                    VALUES ('$question_sql', '$answer_sql', $score_sql, NOW())";

            if (!$conn->query($sql)) {
                $error_message = "Errore DB: " . $conn->error;
            }
        }
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<title>Risposta AI</title>
<link rel="stylesheet" href="style.css">
</head>

<body>

<div class="container">

<h1>Risultato della Conversazione</h1>

<?php if (isset($error_message)) { ?>

    <div class="warning">
        <?php echo htmlspecialchars($error_message); ?>
    </div>

<?php } else { ?>

    <div class="question-box">
        <strong>Domanda:</strong><br>
        <?php echo htmlspecialchars($question); ?>
    </div>

    <div class="answer-box">
        <strong>Risposta AI:</strong><br><br>
        <?php echo nl2br(htmlspecialchars($answer_original)); ?>
    </div>

    <div class="answer-box">
        <strong>Punteggio consapevolezza digitale:</strong>
        <?php echo $score; ?>/5
    </div>

<?php } ?>

<div class="footer">

    <p>
        <a href="index.php">Torna alla chat</a>
    </p>

    <p>
        <a href="history.php">Vedi cronologia</a>
    </p>

</div>

</div>

</body>
</html>
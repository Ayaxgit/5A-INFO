<?php
// index.php
?>
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<title>Digital Citizen AI</title>

<link rel="stylesheet" href="style.css">

</head>
<body>

<div class="container">

<div class="header">
    <h1 class="main-title">Cittadinanza Digitale</h1>
    <div class="sub-title">AI per studenti</div>
</div>

<div class="layout">

<!-- CHAT -->
<div class="chat-box">

<p class="subtitle">
Fai una domanda sulla <strong>cittadinanza digitale</strong>
</p>

<form action="chat.php" method="POST">

<textarea name="question" id="question" placeholder="Scrivi qui la tua domanda..." required></textarea>

<div class="warning">
⚠ Non inserire informazioni personali o riferimenti ad altre persone
</div>

<button type="submit">Invia domanda</button>

</form>

<p class="history-link">
<a href="history.php">Cronologia domande (FAQ)</a>
</p>

</div>

<!-- INFO -->
<div class="info-box">

<div class="info-section">
<strong>Obiettivi</strong>
<ul>
<li>Stimolare domande consapevoli</li>
<li>Sviluppare pensiero critico</li>
<li>Costruire conoscenza condivisa</li>
</ul>
</div>

<div class="info-section">
<strong>Temi</strong>
<ul>
<li>Privacy</li>
<li>Sicurezza online</li>
<li>Fake news</li>
<li>AI e società</li>
</ul>
</div>

</div>

</div>

</div>

</body>
</html>